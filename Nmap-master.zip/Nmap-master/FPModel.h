#ifndef _FPMODEL_H_
#define _FPMODEL_H_

extern struct model FPModel;
extern double FPscale[][2];
extern double FPmean[][695];
extern double FPvariance[][695];
extern FingerMatch FPmatches[];

#endif
